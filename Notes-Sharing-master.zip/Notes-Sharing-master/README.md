#Notes Sharing Website

Home Page

![img](https://github.com/vaishnavitekle/Notes-Sharing/blob/15dbeb3a706e6290d29d359035d52a28b9ae873c/Screenshot%20(93).png)

Registation Page

![img](https://github.com/vaishnavitekle/Notes-Sharing/blob/15dbeb3a706e6290d29d359035d52a28b9ae873c/Screenshot%20(94).png)

Login Page

![img](https://github.com/vaishnavitekle/Notes-Sharing/blob/15dbeb3a706e6290d29d359035d52a28b9ae873c/Screenshot%20(95).png)

##Notes

![img](https://github.com/vaishnavitekle/Notes-Sharing/blob/15dbeb3a706e6290d29d359035d52a28b9ae873c/Screenshot%20(100).png)
